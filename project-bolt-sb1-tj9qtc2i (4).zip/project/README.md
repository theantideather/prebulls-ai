# PreBulls - AI Trading Analysis Platform 🚀

PreBulls is an advanced AI-powered trading analysis platform that helps traders make informed decisions through pattern recognition and market analysis.

![PreBulls Banner](https://images.unsplash.com/photo-1611974789855-9c2a0a7236a3?auto=format&fit=crop&w=1200&h=400)

## ✨ Features

- 🤖 Real-time chart analysis using AI
- 📊 Pattern recognition for technical analysis
- 💹 Support and resistance level detection
- 📈 Trade setup recommendations
- 🌡️ Market sentiment analysis
- 💱 Integration with Jupiter Protocol for trading
- 💬 Community chat for traders

## 🛠️ Tech Stack

- React + TypeScript
- Vite for bundling
- Tailwind CSS for styling
- Supabase for backend
- Jupiter Protocol for Solana trading
- Gemini AI for chart analysis

## 🚀 Getting Started

1. Clone the repository:
   \`\`\`bash
   git clone https://github.com/prebulls/prebulls.git
   cd prebulls
   \`\`\`

2. Install dependencies:
   \`\`\`bash
   npm install
   \`\`\`

3. Copy \`.env.example\` to \`.env\` and fill in your environment variables:
   \`\`\`bash
   cp .env.example .env
   \`\`\`

4. Start the development server:
   \`\`\`bash
   npm run dev
   \`\`\`

## 🤝 Contributing

We welcome contributions! Please see our [Contributing Guide](CONTRIBUTING.md) for details.

## 📝 License

This project is licensed under the MIT License - see the [LICENSE](LICENSE) file for details.

## 🔒 Security

For security concerns, please email security@prebulls.com instead of using the issue tracker.

## 🙏 Acknowledgments

- [Jupiter Protocol](https://jup.ag) for DEX aggregation
- [Supabase](https://supabase.com) for backend services
- [Gemini AI](https://deepmind.google/technologies/gemini/) for AI analysis