import React from 'react';
import { WalletConnect } from '../components/WalletConnect';
import { AuthButton } from '../components/Auth/AuthButton';

interface MainLayoutProps {
  children: React.ReactNode;
}

export function MainLayout({ children }: MainLayoutProps) {
  return (
    <div className="min-h-screen bg-gradient-to-b from-blue-900 to-green-900">
      <div className="max-w-4xl mx-auto px-4 py-4 sm:py-8">
        {/* Fixed header section */}
        <div className="fixed top-0 left-0 right-0 z-50 bg-gradient-to-b from-blue-900 to-transparent py-4 px-4">
          <div className="max-w-4xl mx-auto flex justify-between items-center">
            <div>
              <h1 className="text-2xl sm:text-4xl font-black text-white
                           drop-shadow-[2px_2px_0px_rgba(0,0,0,1)]">
                PreBulls
              </h1>
              <p className="text-sm sm:text-lg text-gray-300 font-bold
                          drop-shadow-[1px_1px_0px_rgba(0,0,0,1)]">
                The Best AI Trader in the World
              </p>
            </div>
            <div className="flex items-center gap-4">
              <AuthButton />
              <WalletConnect />
            </div>
          </div>
        </div>

        {/* Main content with padding for fixed header */}
        <div className="pt-24 sm:pt-32">
          <div className="w-full max-w-3xl mx-auto">
            {children}
          </div>
        </div>
      </div>
    </div>
  );
}