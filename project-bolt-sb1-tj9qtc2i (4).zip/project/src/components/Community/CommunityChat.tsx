import React from 'react';
import { MessageCircle, Users, AlertTriangle } from 'lucide-react';
import { useChat } from '../../contexts/ChatContext';
import { ChatMessage } from './ChatMessage';
import { ChatInput } from './ChatInput';
import { supabase } from '../../lib/supabase';

export function CommunityChat() {
  const { messages, loading, error } = useChat();
  const messagesEndRef = React.useRef<HTMLDivElement>(null);

  React.useEffect(() => {
    scrollToBottom();
  }, [messages]);

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  const currentUser = supabase.auth.getUser()?.data?.user;

  return (
    <div className="bg-white border-2 border-black rounded-lg p-6 shadow-[4px_4px_0px_0px_rgba(0,0,0,1)]">
      <div className="flex items-center gap-3 mb-6">
        <MessageCircle className="w-6 h-6 text-blue-600" />
        <h2 className="text-2xl font-bold text-gray-900">Traders Community</h2>
      </div>

      <div className="space-y-6">
        <div className="flex items-center justify-between p-4 bg-gray-50 border-2 border-black rounded-lg">
          <div className="flex items-center gap-3">
            <Users className="w-5 h-5 text-green-600" />
            <div>
              <p className="font-bold text-gray-900">Trading Discussion</p>
              <p className="text-sm text-gray-600">Share insights and discuss trades</p>
            </div>
          </div>
          <div className="flex gap-2">
            <span className="px-3 py-1 bg-green-100 text-green-800 rounded-full text-sm font-medium">
              Live
            </span>
          </div>
        </div>

        <div className="bg-gray-50 border-2 border-black rounded-lg">
          <div className="bg-white border-b-2 border-black rounded-t-lg p-4 h-[400px] overflow-y-auto">
            {error ? (
              <div className="flex flex-col items-center justify-center h-full gap-4">
                <div className="flex items-center gap-2 text-red-600">
                  <AlertTriangle className="w-5 h-5" />
                  <p>{error}</p>
                </div>
              </div>
            ) : loading ? (
              <div className="flex items-center justify-center h-full">
                <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-blue-600"></div>
              </div>
            ) : messages.length === 0 ? (
              <p className="text-center text-gray-500 my-4">
                No messages yet. Be the first to start the conversation!
              </p>
            ) : (
              messages.map((message) => (
                <ChatMessage
                  key={message.id}
                  message={message}
                  isOwnMessage={message.user_id === currentUser?.id}
                />
              ))
            )}
            <div ref={messagesEndRef} />
          </div>

          {!currentUser ? (
            <div className="p-4 bg-blue-50 border-t-2 border-black">
              <p className="text-center text-blue-700">
                Please sign in to participate in the chat
              </p>
            </div>
          ) : (
            <ChatInput />
          )}
        </div>
      </div>
    </div>
  );
}