import React from 'react';
import { formatDistanceToNow } from 'date-fns';
import type { Message } from '../../types';

interface ChatMessageProps {
  message: Message;
  isOwnMessage: boolean;
}

export function ChatMessage({ message, isOwnMessage }: ChatMessageProps) {
  return (
    <div className={`flex ${isOwnMessage ? 'justify-end' : 'justify-start'} mb-4`}>
      <div className={`flex items-start max-w-[70%] ${isOwnMessage ? 'flex-row-reverse' : 'flex-row'}`}>
        <img
          src={message.user.avatar_url || `https://api.dicebear.com/7.x/avataaars/svg?seed=${message.user.username}`}
          alt={message.user.username}
          className="w-8 h-8 rounded-full flex-shrink-0 mx-2"
        />
        
        <div className={`flex flex-col ${isOwnMessage ? 'items-end' : 'items-start'}`}>
          <div className={`px-4 py-2 rounded-lg ${
            isOwnMessage 
              ? 'bg-blue-600 text-white rounded-tr-none' 
              : 'bg-gray-100 text-gray-900 rounded-tl-none'
          }`}>
            {message.image_url && (
              <img 
                src={message.image_url} 
                alt="Shared chart"
                className="max-w-full rounded-lg mb-2"
              />
            )}
            <p className="break-words">{message.content}</p>
          </div>
          
          <div className="flex items-center mt-1 space-x-2">
            <span className="text-xs text-gray-500">{message.user.username}</span>
            <span className="text-xs text-gray-400">
              {formatDistanceToNow(new Date(message.created_at), { addSuffix: true })}
            </span>
          </div>
        </div>
      </div>
    </div>
  );
}