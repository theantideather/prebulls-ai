```ts
export * from './WalletConnect';
```