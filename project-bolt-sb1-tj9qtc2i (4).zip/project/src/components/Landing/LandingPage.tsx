import React from 'react';
import { Brain, Zap, Shield, Clock, Star } from 'lucide-react';

export function LandingPage() {
  return (
    <div className="space-y-16 py-8">
      {/* Hero Section */}
      <section className="text-center space-y-6">
        <h1 className="text-4xl sm:text-6xl font-black text-white 
                     drop-shadow-[2px_2px_0px_rgba(0,0,0,1)]">
          Trade Like The Future Is Already Here
        </h1>
        <p className="text-xl sm:text-2xl text-gray-300 font-bold
                    drop-shadow-[1px_1px_0px_rgba(0,0,0,1)]">
          While others watch charts, our AI watches everything.
        </p>
      </section>

      {/* Features Section */}
      <section className="grid md:grid-cols-2 lg:grid-cols-4 gap-6">
        {[
          {
            icon: Brain,
            title: 'AI Trading Companion',
            description: 'Your personal JARVIS for trading decisions'
          },
          {
            icon: Zap,
            title: 'Real-time Intelligence',
            description: 'Instant market analysis and pattern recognition'
          },
          {
            icon: Shield,
            title: 'Risk Management',
            description: 'Advanced algorithms protect your investments'
          },
          {
            icon: Clock,
            title: 'Trade While You Sleep',
            description: 'Automated 24/7 market monitoring'
          }
        ].map((feature, index) => (
          <div key={index} className="bg-white border-4 border-black rounded-xl p-6
                                  shadow-[8px_8px_0px_0px_rgba(0,0,0,1)]
                                  hover:shadow-[12px_12px_0px_0px_rgba(0,0,0,1)]
                                  transition-all duration-300">
            <div className="flex justify-center mb-4">
              <div className="bg-red-100 p-3 rounded-full">
                <feature.icon className="w-8 h-8 text-red-600" />
              </div>
            </div>
            <h3 className="font-bold text-gray-900 mb-2 text-center">{feature.title}</h3>
            <p className="text-gray-700 text-sm text-center">{feature.description}</p>
          </div>
        ))}
      </section>

      {/* Origin Story Section */}
      <section className="bg-white border-4 border-black rounded-xl p-8
                       shadow-[8px_8px_0px_0px_rgba(0,0,0,1)]">
        <h2 className="text-3xl font-bold text-gray-900 mb-6">Our Origin Story</h2>
        <p className="text-gray-700 leading-relaxed mb-6">
          Back in 2022, during the crypto market crash, we witnessed countless traders making
          emotional decisions that cost them dearly. That's when we had our eureka moment -
          what if we could take emotions out of trading completely?
        </p>
        <p className="text-gray-700 leading-relaxed">
          After two years of development and countless iterations, we've built something that
          would make Wall Street jealous. But here's the twist - we didn't build it for
          Wall Street. We built it for you.
        </p>
      </section>

      {/* Testimonials Section */}
      <section className="grid md:grid-cols-3 gap-6">
        {[
          {
            quote: "It's like having a professional trader in my pocket",
            author: "Sarah K."
          },
          {
            quote: "Finally, I can sleep without worrying about my positions",
            author: "Mike R."
          },
          {
            quote: "This isn't just the future of trading - it's already here",
            author: "Alex T."
          }
        ].map((testimonial, index) => (
          <div key={index} className="bg-white border-4 border-black rounded-xl p-6
                                  shadow-[8px_8px_0px_0px_rgba(0,0,0,1)]">
            <div className="flex justify-center mb-4">
              <Star className="w-8 h-8 text-yellow-400 fill-current" />
            </div>
            <blockquote className="text-gray-700 text-center mb-4">
              "{testimonial.quote}"
            </blockquote>
            <p className="text-gray-900 font-bold text-center">- {testimonial.author}</p>
          </div>
        ))}
      </section>

      {/* CTA Section */}
      <section className="text-center">
        <h2 className="text-3xl font-bold text-white mb-6
                     drop-shadow-[2px_2px_0px_rgba(0,0,0,1)]">
          Ready to Step Into the Future of Trading?
        </h2>
        <p className="text-xl text-gray-300 mb-8
                    drop-shadow-[1px_1px_0px_rgba(0,0,0,1)]">
          Join us and revolutionize your trading journey today.
        </p>
      </section>
    </div>
  );
}