export interface PaymentRequest {
  recipient: string;
  amount: number;
  splToken: string;
  reference: string;
  label: string;
  message: string;
}

export interface PaymentStatus {
  success: boolean;
  error?: string;
  signature?: string;
}