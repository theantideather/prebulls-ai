export const CHART_ANALYSIS_PROMPT = `Analyze this trading chart and provide a detailed technical analysis in JSON format with the following structure:

{
  "trend": "bullish/bearish/neutral",
  "confidence": 0-100,
  "supportLevels": ["level1", "level2", ...],
  "resistanceLevels": ["level1", "level2", ...],
  "patterns": ["pattern1", "pattern2", ...],
  "marketSentiment": {
    "fearGreedIndex": 0-100,
    "sentiment": "fear/greed/neutral",
    "dominantTrend": "string",
    "volumeAnalysis": "string"
  },
  "tradeSetups": [
    {
      "pattern": "string",
      "direction": "long/short",
      "entry": "price",
      "stopLoss": "price",
      "target": "price",
      "probability": 0-100
    }
  ]
}

Consider:
1. Price action and trend direction
2. Support and resistance levels
3. Chart patterns (flags, triangles, etc.)
4. Volume analysis
5. Market structure
6. Potential trade setups

Provide specific price levels and clear trade setups with risk management.`;