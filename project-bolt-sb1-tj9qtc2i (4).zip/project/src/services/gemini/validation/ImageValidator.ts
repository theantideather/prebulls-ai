import { GEMINI_CONFIG } from '../config';

export class ImageValidator {
  validate(imageBase64: string): void {
    if (!imageBase64) {
      throw new Error('No image data provided');
    }

    const base64Data = imageBase64.split(',')[1] || imageBase64;
    
    if (!this.isValidBase64(base64Data)) {
      throw new Error('Invalid image data format');
    }
  }

  private isValidBase64(str: string): boolean {
    try {
      return btoa(atob(str)) === str;
    } catch {
      return false;
    }
  }
}