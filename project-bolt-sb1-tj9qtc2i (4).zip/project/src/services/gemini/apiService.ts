import { ChartAnalysis } from '../../types';
import { ChartAnalyzer } from './analysis/analyzers/ChartAnalyzer';

export class GeminiService {
  private analyzer: ChartAnalyzer;

  constructor() {
    const apiKey = import.meta.env.VITE_GEMINI_API_KEY;
    if (!apiKey) {
      throw new Error('Gemini API key is not configured. Please check your .env file.');
    }
    this.analyzer = new ChartAnalyzer(apiKey);
  }

  async analyzeChart(imageBase64: string): Promise<ChartAnalysis> {
    try {
      return await this.analyzer.analyzeChart(imageBase64);
    } catch (error) {
      console.error('Gemini Service Error:', error);
      throw error;
    }
  }
}