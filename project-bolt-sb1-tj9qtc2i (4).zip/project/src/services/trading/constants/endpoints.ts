export const JUPITER_ENDPOINTS = {
  QUOTE: 'https://quote-api.jup.ag/v6/quote',
  SWAP: 'https://quote-api.jup.ag/v6/swap'
} as const;