import React from 'react';
import { MainLayout } from './layouts/MainLayout';
import { LandingPage } from './components/Landing/LandingPage';
import { ChartAnalysisWindow } from './components/ChartAnalysis';
import { CommunityChat } from './components/Community';
import { ContactPage } from './components/Contact';
import { ChatProvider } from './contexts/ChatContext';

export function App() {
  return (
    <ChatProvider>
      <MainLayout>
        <ChartAnalysisWindow />
        <LandingPage />
        <div className="space-y-8">
          <CommunityChat />
          <ContactPage />
        </div>
      </MainLayout>
    </ChatProvider>
  );
}