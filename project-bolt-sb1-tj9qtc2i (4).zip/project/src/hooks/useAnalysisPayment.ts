import { useState, useEffect } from 'react';
import { UsageTracker } from '../services/payments/usageTracker';
import { SolanaPayService } from '../services/payments/solanaPay';

export function useAnalysisPayment() {
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  // Check for payment confirmation on return from Solana Pay
  useEffect(() => {
    const urlParams = new URLSearchParams(window.location.search);
    const status = urlParams.get('status');
    const signature = urlParams.get('signature');

    if (status === 'success' && signature) {
      UsageTracker.setPaid(true);
      UsageTracker.resetAttempts();
      // Clean up URL
      window.history.replaceState({}, '', window.location.pathname);
    }
  }, []);

  const checkAndProcessAnalysis = async (): Promise<boolean> => {
    try {
      setLoading(true);
      setError(null);

      if (UsageTracker.needsPayment()) {
        const paymentUrl = await SolanaPayService.initiatePayment();
        window.location.href = paymentUrl;
        return false;
      }

      UsageTracker.incrementAttempts();
      return true;
    } catch (err: any) {
      setError(err.message);
      return false;
    } finally {
      setLoading(false);
    }
  };

  return {
    checkAndProcessAnalysis,
    loading,
    error,
    attemptsLeft: UsageTracker.getRemainingAttempts(),
    hasPaid: UsageTracker.hasPaid(),
    maxAttempts: UsageTracker.getMaxAttempts()
  };
}